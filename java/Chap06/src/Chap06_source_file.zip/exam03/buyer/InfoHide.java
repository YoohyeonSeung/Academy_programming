package exam03.buyer; //현재 자바 파일이 어디 폴더에 있는지 써있는거임

import exam03.Buyer;

public class InfoHide {
	Buyer buyer = new Buyer("어머니", 10000, 0);
	//exam03.Buyer buyer = new exam03.Buyer("어머니", 10000, 0); import가 없다면 옆에 있는것 처럼 써야됨
	
	
}
