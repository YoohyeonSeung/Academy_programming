package exam07;
class Adder {
	
	public int add(int n1, int n2) {return n1+n2;	}
	public double add(double n1, double n2) {return n1+n2;	}
	public double add(int n1, double n2) {return n1+n2;	}
	public double add(double n1, int n2) {return n1+n2;	}
	public int add(int n1, int n2, int n3) {return n1+n2+n3;	}
	//입력의 자료형이 다르면 같은이름으로의 메소드 정의를 허용!
	

}
	

