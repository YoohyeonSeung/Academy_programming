package YooHS181127;

import java.util.Scanner;

public class AddressBook {

	public static void main(String[] args) {
		
		Menu menu = new Menu();		
	
		
		menu.displayMenu();
		

	}

}
